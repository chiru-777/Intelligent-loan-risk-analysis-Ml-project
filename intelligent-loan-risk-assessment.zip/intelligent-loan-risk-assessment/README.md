# Intelligent Loan Risk Assessment System

Run in VS Code with Python.

## Setup
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Train
```powershell
python train_models.py
```

## Run
```powershell
streamlit run app.py
```

The training script automatically creates a realistic loan applicant dataset if none exists, trains SVM, KNN, Random Forest, Gradient Boosting, Soft Voting and Stacking models, evaluates them, and saves model/plot artifacts.
