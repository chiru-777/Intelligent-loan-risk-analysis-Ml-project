from pathlib import Path
BASE_DIR=Path(__file__).resolve().parent
RAW_DATA_DIR=BASE_DIR/'data/raw'; PROCESSED_DATA_DIR=BASE_DIR/'data/processed'; MODELS_DIR=BASE_DIR/'models'; PLOTS_DIR=BASE_DIR/'outputs/plots'; METRICS_DIR=BASE_DIR/'outputs/metrics'
FEATURES=['age','annual_income','employment_status','credit_score','loan_amount','loan_term','existing_debt','debt_to_income_ratio','credit_history','payment_history','previous_loans','assets']
TARGET='risk'; RANDOM_STATE=42
