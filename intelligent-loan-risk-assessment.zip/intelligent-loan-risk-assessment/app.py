import joblib,pandas as pd,streamlit as st,plotly.express as px
from pathlib import Path
from config import *
st.set_page_config(page_title='Intelligent Loan Risk Assessment',page_icon='💳',layout='wide')
NAMES=['SVM','KNN','Random Forest','Gradient Boosting','Soft Voting','Stacking']
def models(): return {n:joblib.load(MODELS_DIR/(n.lower().replace(' ','_')+'.joblib')) for n in NAMES if (MODELS_DIR/(n.lower().replace(' ','_')+'.joblib')).exists()}
def data():
 p=RAW_DATA_DIR/'loan_applicants.csv'; return pd.read_csv(p) if p.exists() else None
st.sidebar.title('Navigation'); page=st.sidebar.radio('Go to',['Dashboard','Risk Prediction','What-If Simulator','Model Comparison','Explainable AI','Dataset'])
ms=models(); df=data()
if page=='Dashboard':
 st.title('💳 Intelligent Loan Risk Assessment System'); st.write('ML-based loan risk prediction using multiple classifiers, ensemble learning, SHAP and What-If simulation.'); a,b,c,d=st.columns(4); a.metric('Dataset Rows',len(df) if df is not None else 0); b.metric('ML Models',6); c.metric('Ensembles',2); d.metric('Explainability','SHAP'); st.info('Loan Data → Preprocessing → Feature Selection → Multiple ML Models → Voting / Stacking → Risk Prediction → Explanation + What-If Analysis')
elif not ms: st.warning('Models are not trained. Run: python train_models.py')
elif page in ['Risk Prediction','What-If Simulator']:
 st.title('🔎 '+page); col1,col2=st.columns(2)
 with col1:
  age=st.slider('Age',18,70,32); income=st.number_input('Annual Income',10000,500000,60000,5000); emp=st.selectbox('Employment Status',['Salaried','Self-Employed','Contract','Unemployed']); cs=st.slider('Credit Score',300,850,680); loan=st.number_input('Loan Amount',1000,500000,50000,5000); term=st.selectbox('Loan Term',[12,24,36,48,60,72])
 with col2:
  debt=st.number_input('Existing Debt',0,500000,25000,2500); dti=st.slider('Debt-to-Income Ratio (%)',0.,80.,25.,.5); ch=st.selectbox('Credit History',['Good','Average','Poor']); ph=st.selectbox('Payment History',['On Time','Occasional Delay','Frequent Delay']); prev=st.slider('Previous Loans',0,15,2); assets=st.number_input('Assets',0,1000000,100000,5000)
 row=pd.DataFrame([dict(age=age,annual_income=income,employment_status=emp,credit_score=cs,loan_amount=loan,loan_term=term,existing_debt=debt,debt_to_income_ratio=dti,credit_history=ch,payment_history=ph,previous_loans=prev,assets=assets)])
 name=st.selectbox('Model',['Soft Voting','Stacking','Random Forest'] if page=='What-If Simulator' else NAMES); p=float(ms[name].predict_proba(row)[0,1]); st.metric('High-Risk Probability',f'{p:.2%}'); st.subheader('Prediction: '+('HIGH RISK' if p>=.5 else 'LOW RISK'))
 if page=='What-If Simulator': st.info('Change the inputs above and observe the actual trained-model probability. This is for educational demonstration and is not financial advice or a loan guarantee.')
elif page=='Model Comparison':
 st.title('📊 Model Comparison'); m=pd.read_csv(METRICS_DIR/'model_metrics.csv'); st.dataframe(m.style.format({c:'{:.2%}' for c in m.columns[1:]}),use_container_width=True); st.plotly_chart(px.bar(m,x='Model',y=['Accuracy','Precision','Recall','F1','ROC-AUC'],barmode='group'),use_container_width=True); p=PLOTS_DIR/'roc_comparison.png'; st.image(str(p)) if p.exists() else None
elif page=='Explainable AI':
 st.title('🧠 Explainable AI'); st.write('SHAP-based explanation of the Random Forest model.');
 try:
  import shap
  name='Random Forest'; model=ms[name]; sample=df[FEATURES].dropna().sample(1,random_state=42); pre=model.named_steps['pre']; est=model.named_steps['model']; z=pre.transform(sample); ex=shap.TreeExplainer(est); vals=ex.shap_values(z); vals=vals[1][0] if isinstance(vals,list) else vals[0]; names=pre.get_feature_names_out(); x=pd.DataFrame({'Feature':names,'Impact':vals}); x['abs']=x.Impact.abs(); x=x.nlargest(12,'abs').sort_values('Impact'); st.dataframe(sample,use_container_width=True); st.plotly_chart(px.bar(x,x='Impact',y='Feature',orientation='h',title='SHAP Feature Impact'),use_container_width=True)
 except Exception as e: st.warning('SHAP explanation could not be generated for this environment: '+str(e))
elif page=='Dataset':
 st.title('📁 Dataset & Analysis'); st.dataframe(df.head(20),use_container_width=True); st.plotly_chart(px.histogram(df,x='credit_score',color='risk',nbins=30,title='Credit Score Distribution by Risk'),use_container_width=True); st.plotly_chart(px.scatter(df,x='annual_income',y='loan_amount',color=df.risk.map({0:'Low Risk',1:'High Risk'}),title='Income vs Loan Amount'),use_container_width=True)
