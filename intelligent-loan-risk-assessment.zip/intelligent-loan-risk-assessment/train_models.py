import numpy as np,pandas as pd,joblib
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier,GradientBoostingClassifier,VotingClassifier,StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score,roc_auc_score,confusion_matrix,ConfusionMatrixDisplay,roc_curve
import matplotlib.pyplot as plt
from config import *
CAT=['employment_status','credit_history','payment_history']; NUM=[x for x in FEATURES if x not in CAT]
def make_data(n=1500):
 r=np.random.default_rng(RANDOM_STATE); age=r.integers(21,66,n); income=r.integers(18000,180000,n); emp=r.choice(['Salaried','Self-Employed','Contract','Unemployed'],n,p=[.5,.25,.15,.1]); cs=np.clip(r.normal(680,75,n),300,850).round(); loan=r.integers(5000,120000,n); term=r.choice([12,24,36,48,60,72],n); debt=r.integers(0,80000,n); dti=np.clip((debt+loan*.08)/income*100,1,75); ch=r.choice(['Good','Average','Poor'],n,p=[.55,.3,.15]); ph=r.choice(['On Time','Occasional Delay','Frequent Delay'],n,p=[.68,.22,.1]); prev=r.integers(0,8,n); assets=r.integers(5000,300000,n)
 s=2.4-.012*(cs-650)-.000012*(income-50000)+.000018*loan+.015*dti+.000008*debt-.000003*assets+(emp=='Unemployed')*1.5+(ch=='Poor')*1.4+(ch=='Average')*.45+(ph=='Frequent Delay')*1.3+(ph=='Occasional Delay')*.45-.08*prev+r.normal(0,.8,n); y=(1/(1+np.exp(-s))>.5).astype(int)
 df=pd.DataFrame(dict(age=age,annual_income=income,employment_status=emp,credit_score=cs,loan_amount=loan,loan_term=term,existing_debt=debt,debt_to_income_ratio=dti.round(2),credit_history=ch,payment_history=ph,previous_loans=prev,assets=assets,risk=y)); RAW_DATA_DIR.mkdir(parents=True,exist_ok=True); df.to_csv(RAW_DATA_DIR/'loan_applicants.csv',index=False); return df
def main():
 for p in [MODELS_DIR,PLOTS_DIR,METRICS_DIR,PROCESSED_DATA_DIR]: p.mkdir(parents=True,exist_ok=True)
 df=make_data(); df.to_csv(PROCESSED_DATA_DIR/'loan_applicants_processed.csv',index=False); X=df[FEATURES]; y=df[TARGET]; Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,stratify=y,random_state=RANDOM_STATE)
 pre=ColumnTransformer([('num',Pipeline([('imp',SimpleImputer(strategy='median')),('scale',StandardScaler())]),NUM),('cat',Pipeline([('imp',SimpleImputer(strategy='most_frequent')),('enc',OneHotEncoder(handle_unknown='ignore'))]),CAT)])
 base=[('svm',SVC(probability=True,random_state=42)),('knn',KNeighborsClassifier(7)),('rf',RandomForestClassifier(n_estimators=200,class_weight='balanced',random_state=42)),('gb',GradientBoostingClassifier(random_state=42))]
 estimators=dict(SVM=base[0][1],KNN=base[1][1],**{'Random Forest':base[2][1]},**{'Gradient Boosting':base[3][1]})
 estimators['Soft Voting']=VotingClassifier(base,voting='soft'); estimators['Stacking']=StackingClassifier(base,final_estimator=LogisticRegression(max_iter=1000),stack_method='predict_proba')
 rows=[]
 for name,est in estimators.items():
  pipe=Pipeline([('pre',pre),('model',est)]); pipe.fit(Xtr,ytr); joblib.dump(pipe,MODELS_DIR/(name.lower().replace(' ','_')+'.joblib')); pr=pipe.predict(Xte); prob=pipe.predict_proba(Xte)[:,1]; rows.append([name,accuracy_score(yte,pr),precision_score(yte,pr,zero_division=0),recall_score(yte,pr,zero_division=0),f1_score(yte,pr,zero_division=0),roc_auc_score(yte,prob)])
  ConfusionMatrixDisplay(confusion_matrix(yte,pr),display_labels=['Low Risk','High Risk']).plot(); plt.title(name+' Confusion Matrix'); plt.tight_layout(); plt.savefig(PLOTS_DIR/(name.lower().replace(' ','_')+'_cm.png')); plt.close()
 pd.DataFrame(rows,columns=['Model','Accuracy','Precision','Recall','F1','ROC-AUC']).to_csv(METRICS_DIR/'model_metrics.csv',index=False)
 fig,ax=plt.subplots(figsize=(8,5))
 for name,est in estimators.items():
  pipe=joblib.load(MODELS_DIR/(name.lower().replace(' ','_')+'.joblib')); fpr,tpr,_=roc_curve(yte,pipe.predict_proba(Xte)[:,1]); ax.plot(fpr,tpr,label=name)
 ax.plot([0,1],[0,1],'--'); ax.legend(); ax.set_xlabel('False Positive Rate'); ax.set_ylabel('True Positive Rate'); ax.set_title('ROC Curve Comparison'); plt.tight_layout(); plt.savefig(PLOTS_DIR/'roc_comparison.png'); plt.close()
 print(pd.DataFrame(rows,columns=['Model','Accuracy','Precision','Recall','F1','ROC-AUC']).to_string(index=False)); print('\nTraining completed successfully.')
if __name__=='__main__': main()
